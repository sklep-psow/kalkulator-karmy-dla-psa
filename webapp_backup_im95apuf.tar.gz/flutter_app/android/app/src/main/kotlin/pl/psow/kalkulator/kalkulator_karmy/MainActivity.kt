package pl.psow.kalkulator.kalkulator_karmy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
